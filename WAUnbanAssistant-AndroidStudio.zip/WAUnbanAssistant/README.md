# WA UNBAN ASSISTANT

Aplikasi Android Kotlin + Jetpack Compose untuk panduan pemulihan akun WhatsApp melalui jalur resmi.

## Fitur
- Dashboard dan panduan pemeriksaan status pemblokiran.
- Panduan pemulihan melalui aplikasi dan dukungan resmi WhatsApp.
- Appeal Generator dengan draf pesan dan tombol salin.
- Pengaturan dan informasi privasi.
- Tidak meminta OTP/PIN/password dan tidak mengirim data ke server.

## Persyaratan
- Android Studio terbaru yang mendukung Android Gradle Plugin 8.7.3.
- JDK 17.
- Android SDK Platform 35.
- Minimum Android 8.0 (API 26).

## Cara membangun APK
1. Ekstrak folder proyek.
2. Buka folder `WAUnbanAssistant` melalui Android Studio.
3. Tunggu Gradle Sync selesai dan izinkan Android Studio mengunduh dependensi.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: aplikasi ini bukan produk resmi WhatsApp dan tidak dapat membuka blokir secara otomatis. Hanya WhatsApp yang dapat memutuskan hasil peninjauan.
