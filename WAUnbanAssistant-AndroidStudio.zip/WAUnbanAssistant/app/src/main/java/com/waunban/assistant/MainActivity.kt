package com.waunban.assistant

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF080D18)
private val Panel = Color(0xFF121C2D)
private val Blue = Color(0xFF32A8FF)
private val Soft = Color(0xFFB8C7D9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WaUnbanApp() }
    }
}

@Composable
fun WaUnbanApp() {
    var selected by remember { mutableIntStateOf(0) }
    val tabs = listOf("Home", "Recovery", "Appeal", "Settings")
    val icons = listOf(Icons.Default.Home, Icons.Default.Restore, Icons.Default.EditNote, Icons.Default.Settings)
    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Navy, surface = Panel)) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Icon(icons[index], contentDescription = label) },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Blue, selectedTextColor = Blue, indicatorColor = Blue.copy(alpha = .15f), unselectedIconColor = Soft, unselectedTextColor = Soft)
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    0 -> HomeScreen(onRecovery = { selected = 1 }, onAppeal = { selected = 2 })
                    1 -> RecoveryScreen()
                    2 -> AppealScreen()
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun Page(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(20.dp), content = content)
}

@Composable
private fun Header(kicker: String, title: String, subtitle: String) {
    Text(kicker.uppercase(), color = Blue, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    Spacer(Modifier.height(8.dp))
    Text(title, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.ExtraBold)
    Spacer(Modifier.height(6.dp))
    Text(subtitle, color = Soft, fontSize = 14.sp)
    Spacer(Modifier.height(22.dp))
}

@Composable
private fun PanelCard(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, contentDescription = null, tint = Blue, modifier = Modifier.size(25.dp))
            Spacer(Modifier.width(13.dp))
            Column { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp); Spacer(Modifier.height(5.dp)); Text(body, color = Soft, fontSize = 13.sp, lineHeight = 19.sp) }
        }
    }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Blue, contentColor = Navy)) {
        Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun HomeScreen(onRecovery: () -> Unit, onAppeal: () -> Unit) {
    Page {
        Header("Account support utility", "WA UNBAN\nASSISTANT", "Panduan aman untuk membantu memahami dan mengajukan peninjauan akun WhatsApp.")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = Blue, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(10.dp)); Text("PUSAT BANTUAN AKUN", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(12.dp))
                Text("Akun diblokir?", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Ikuti langkah resmi. Hanya WhatsApp yang dapat memutuskan hasil peninjauan.", color = Soft, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                PrimaryButton("Mulai pemulihan", onRecovery)
                Spacer(Modifier.height(9.dp))
                OutlinedButton(onClick = onAppeal, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) { Text("Buat pesan banding", color = Blue) }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("FITUR UTAMA", color = Blue, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(12.dp))
        PanelCard("Pemeriksaan status", "Kenali pesan pemblokiran dan pahami kemungkinan penyebabnya.", Icons.Default.Search)
        PanelCard("Panduan pemulihan", "Langkah aman untuk meminta peninjauan melalui aplikasi WhatsApp.", Icons.Default.Restore)
        PanelCard("Privasi", "Aplikasi ini tidak meminta kata sandi, PIN, atau kode OTP WhatsApp.", Icons.Default.Lock)
    }
}

@Composable
private fun RecoveryScreen() {
    val context = LocalContext.current
    Page {
        Header("Recovery guide", "Pemulihan akun", "Gunakan jalur resmi untuk memeriksa dan meminta peninjauan akun.")
        PanelCard("1. Periksa pesan di WhatsApp", "Buka WhatsApp resmi dan baca pemberitahuan yang muncul. Perhatikan apakah tertulis pemblokiran sementara atau akun tidak diizinkan menggunakan WhatsApp.", Icons.Default.Info)
        PanelCard("2. Ajukan peninjauan", "Jika tersedia tombol 'Minta peninjauan' di aplikasi, ikuti petunjuknya dan jelaskan masalah secara jujur. Jangan mengirim permintaan berulang-ulang.", Icons.Default.FactCheck)
        PanelCard("3. Gunakan aplikasi resmi", "Pastikan menggunakan WhatsApp resmi dari Google Play. Hapus aplikasi modifikasi jika sebelumnya digunakan, lalu ikuti instruksi dukungan.", Icons.Default.PhoneAndroid)
        PanelCard("Penting", "Tidak ada aplikasi pihak ketiga yang dapat menjamin membuka blokir. Jangan berikan kode OTP atau PIN kepada siapa pun.", Icons.Default.Shield)
        PrimaryButton("Buka Pusat Bantuan WhatsApp") { openUrl(context, "https://faq.whatsapp.com/") }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { openUrl(context, "https://www.whatsapp.com/contact/") }, modifier = Modifier.fillMaxWidth()) { Text("Hubungi WhatsApp", color = Blue) }
    }
}

@Composable
private fun AppealScreen() {
    var phone by remember { mutableStateOf("") }
    var reason by remember { mutableStateOf("Saya merasa akun saya mungkin diblokir karena kesalahan.") }
    var extra by remember { mutableStateOf("") }
    var generated by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(20.dp)) {
        Header("Appeal generator", "Pesan banding", "Buat draf sopan untuk disampaikan melalui kanal resmi WhatsApp.")
        Text("Nomor WhatsApp (opsional)", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Contoh: +62xxxxxxxxxx") }, singleLine = true, colors = fieldColors())
        Spacer(Modifier.height(15.dp))
        Text("Alasan pengajuan", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        listOf("Saya merasa akun saya mungkin diblokir karena kesalahan.", "Saya ingin meminta pemeriksaan ulang atas aktivitas akun.", "Saya sudah beralih menggunakan aplikasi WhatsApp resmi.").forEach { option ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = reason == option, onClick = { reason = option }, colors = RadioButtonDefaults.colors(selectedColor = Blue, unselectedColor = Soft))
                Text(option, color = Soft, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Keterangan tambahan (opsional)", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        OutlinedTextField(value = extra, onValueChange = { extra = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, placeholder = { Text("Jelaskan situasi secara singkat...") }, colors = fieldColors())
        Spacer(Modifier.height(16.dp))
        PrimaryButton("Buat pesan banding") {
            generated = "Halo Tim Dukungan WhatsApp,\n\nSaya ingin meminta peninjauan terhadap akun WhatsApp saya${if (phone.isBlank()) "" else " dengan nomor $phone"}. $reason\n\n${extra.trim().takeIf { it.isNotBlank() } ?: "Mohon periksa kembali status akun saya."}\n\nSaya bersedia mengikuti Ketentuan Layanan WhatsApp. Terima kasih."
        }
        if (generated.isNotBlank()) {
            Spacer(Modifier.height(16.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(15.dp)) {
                    Text("DRAF PESAN", color = Blue, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(generated, color = Color.White, fontSize = 13.sp, lineHeight = 19.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { clipboard.setText(AnnotatedString(generated)) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.ContentCopy, null, tint = Blue); Spacer(Modifier.width(7.dp)); Text("Salin pesan", color = Blue) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Draf ini bukan pengajuan otomatis. Periksa dan kirim sendiri melalui aplikasi atau situs resmi WhatsApp.", color = Soft, fontSize = 12.sp)
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Blue, unfocusedBorderColor = Soft.copy(alpha = .45f), focusedLabelColor = Blue, unfocusedLabelColor = Soft, cursorColor = Blue)

@Composable
private fun SettingsScreen() {
    val context = LocalContext.current
    Page {
        Header("Preferences", "Pengaturan", "Informasi aplikasi dan tautan bantuan.")
        PanelCard("WA UNBAN ASSISTANT", "Versi 1.0.0\nAplikasi panduan pemulihan akun WhatsApp.", Icons.Default.Apps)
        PanelCard("Privasi pengguna", "Nomor dan keterangan yang Anda masukkan hanya digunakan untuk menyusun draf di layar. Aplikasi ini tidak menyimpan atau mengirimkannya ke server.", Icons.Default.PrivacyTip)
        PanelCard("Peringatan keamanan", "Jangan pernah membagikan kode OTP, PIN verifikasi dua langkah, atau kata sandi kepada pihak lain.", Icons.Default.Security)
        PrimaryButton("Buka FAQ WhatsApp") { openUrl(context, "https://faq.whatsapp.com/") }
        Spacer(Modifier.height(20.dp))
        Text("WA UNBAN ASSISTANT bukan aplikasi resmi atau afiliasi WhatsApp/Meta.", color = Soft, fontSize = 12.sp)
    }
}

private fun openUrl(context: android.content.Context, url: String) {
    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}
